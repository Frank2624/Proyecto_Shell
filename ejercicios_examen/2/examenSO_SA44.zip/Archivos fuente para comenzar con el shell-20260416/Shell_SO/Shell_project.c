//------------------------------------------------------------------------------
// Francisco Rosales Arévalo





// UNIX Shell Project
// 
// Sistemas Operativos
// Dept. Arquitectura de Computadores - UMA
// 
// To compile and run the program:
//    $ gcc Shell_project.c parse_line.c list.c job_control.c -o Shell
//    $ ./Shell          
//    ShellSO > 
//     (then type ^D to exit program)
//------------------------------------------------------------------------------

// standard headers
#include <stdio.h>          // printf, stderr, perror, fprintf
#include <stdlib.h>         // malloc, free
//#include <malloc.h>
#include <string.h>         // strcmp
#include <fcntl.h>          // open
#include <unistd.h>         // fork, execvp, tcgetpgrp, dup2, close
//#include <termios.h>
#include <signal.h>         // signal
#include <sys/wait.h>       // waitpid
//#include <sys/types.h>
#include <errno.h>          // errno

// local project headers
#include "parse_line.h"     // link with parse_line.o
#include "job_control.h"    // link with job_control.o and list.o
#define RESET "\x1b[0m"
#define RED "\x1b[31m"
#define GREEN "\x1b[32m"
#define YELLOW "\x1b[33m"
#define BLUE "\x1b[34m"
#define MAGENTA "\x1b[35m"
#define CYAN "\x1b[36m"
#define WHITE "\x1b[37m"
#define DEFAULT "\x1b[39m"

// -----------------------------------------------------------------------------
//                            Global data structures
// -----------------------------------------------------------------------------
// Declara aqui las variables globales que tengan que ser accedidas desde los
//  manejadores establecidos con signal() o sigaction()

    list_head_t *job_list = NULL; //lista de gestión de tareas

// -----------------------------------------------------------------------------
// Useful functions to deal with signal handlers and signal masks
// -----------------------------------------------------------------------------
// set a handler (SIG_IGN or SIG_DFL) for signal sent by terminal
void terminal_signals(void (*func)(int))
{
    signal(SIGINT,  func); // crtl+c interrupt tecleado en el terminal
    signal(SIGQUIT, func); // ctrl+\ quit tecleado en el terminal
    signal(SIGTSTP, func); // crtl+z Stop tecleado en el terminal
    signal(SIGTTIN, func); // proceso en segundo plano quiere leer del terminal
    signal(SIGTTOU, func); // proceso en segundo plano quiere escribir en el terminal
}
// -----------------------------------------------------------------------------
// mask or unmask a given signal depending on the block argument
void mask_signal(int signal, int block)
{
    sigset_t mask;
    sigemptyset(&mask);
    sigaddset(&mask, signal);
    sigprocmask(block, &mask, NULL); // block: SIG_BLOCK/SIG_UNBLOCK
}
// -----------------------------------------------------------------------------
// EJECUCIÓN DE COMANDOS EXTERNOS
// -----------------------------------------------------------------------------
void execute_external_command(char **argv, int background, char *file_in, char *file_out, int apply_mask, sigset_t custom_mask, int *last_pid, int *retval,int *wstatus) {
    int pid_fork, pid_wait;

    // the steps are:
    // (1) fork a child process using fork()
    pid_fork=fork();
    switch(pid_fork){
    case -1: perror("fork"); return;
    
    case 0: //child
    // (2) the child process will invoke execvp()
            setpgid(getpid(),getpid());
            
            if (!background)tcsetpgrp(STDIN_FILENO,getpid());
            terminal_signals(SIG_DFL);

            if (apply_mask) sigprocmask(SIG_BLOCK, &custom_mask, NULL);


            //Redirecciones de entrada y salida 
            if (file_in!=NULL){
                int f_in=open(file_in,O_RDONLY);

                if(f_in==-1){
                    perror(file_in);
                    exit(EXIT_FAILURE);
                }
                dup2(f_in,STDIN_FILENO);
                close(f_in);
            }
            if (file_out!=NULL){
                int f_out=open(file_out,O_CREAT|O_WRONLY|O_TRUNC,0664);

                if(f_out==-1){
                    perror(file_out);
                    exit(EXIT_FAILURE);
                }
                dup2(f_out,STDOUT_FILENO);
                close(f_out);
            }
            execvp(argv[0],argv);  
            perror(argv[0]);
            exit(EXIT_FAILURE);
    
    default://parent
            setpgid(pid_fork,pid_fork);
            *last_pid = pid_fork;
            mask_signal(SIGCHLD, SIG_BLOCK);
    // (3) if background == 0, the parent will wait, otherwise
            if (!background) {
                pid_wait = waitpid(pid_fork, wstatus, WUNTRACED);
                tcsetpgrp(STDIN_FILENO,getpid());
                
                if (pid_wait == -1){
                    perror("waitpid");
                    mask_signal(SIGCHLD, SIG_UNBLOCK);
                    break;
                } 
    // (4) Shell shows a status message for processed command 
                if (WIFEXITED(*wstatus)) {
                    *retval = WEXITSTATUS(*wstatus);
                    printf("[%d] (%s) Terminated with status: %d\n", pid_fork, argv[0], *retval);
                }
                
                else if (WIFSIGNALED(*wstatus)) {
                    int sig = WTERMSIG(*wstatus);
                    printf("[%d] (%s) Signaled by signal: %d\n", pid_fork, argv[0], sig);
                } 
                
                else if (WIFSTOPPED(*wstatus)){
                    job *task= new_job(pid_fork,argv[0],STOPPED);
                    add_job(job_list,task);
                    printf("[%d] (%s) Stopped by signal: %d\n", pid_fork, argv[0], WSTOPSIG(*wstatus));
                } 
                
                else printf("[%d] (%s) other\n", pid_fork, argv[0]);
                
    // Gestiono las tareas lanzadas en BACKGROUND
           } else{
                job *task= new_job(pid_fork,argv[0],BACKGROUND);
                add_job(job_list,task);
               printf("[%d] (%s) Running in Background\n", pid_fork, argv[0]);
           } 
           mask_signal(SIGCHLD, SIG_UNBLOCK);
        
    // (5) loop ret
    }
}
// -----------------------------------------------------------------------------
// EJECUCIÓN DE COMANDOS EXTERNOS CON PIPE
// -----------------------------------------------------------------------------
//Aquí ejecuto los comandos del pipe, primero creo un hijo con el primer comando, cuya salida irá al pipe y luego creo un segundo hijo 
// que pertenece al mismo grupo de procesos del primero y recibe como entrada el pipe
void execute_external_command_pipe(char **argv, char **argv_cmd2, int background, char *file_in, char *file_out2, int apply_mask, sigset_t custom_mask, int *last_pid, int *retval, int *wstatus) {
    int pid_fork, pid_fork2, pid_wait;
    int p[2];
    pipe(p); //p[0] lectura y p[1] escritura

    pid_fork=fork();
    switch(pid_fork){
        case -1: perror("fork");
                 break;
        case 0: //child 1 
                setpgid(getpid(),getpid());
                
                if (!background)tcsetpgrp(STDIN_FILENO,getpid());
                terminal_signals(SIG_DFL);

                if (apply_mask) sigprocmask(SIG_BLOCK, &custom_mask, NULL);


                //Redireccion de entrada 
                if (file_in!=NULL){
                    int f_in=open(file_in,O_RDONLY);

                    if(f_in==-1){
                        perror(file_in);
                        exit(EXIT_FAILURE);
                    }
                    dup2(f_in,STDIN_FILENO);
                    close(f_in);
                }

                dup2(p[1],STDOUT_FILENO);
                close(p[0]);
                close(p[1]);


                execvp(argv[0],argv);  
                perror(argv[0]);
                exit(EXIT_FAILURE);
        
        default:
                pid_fork2=fork();
                switch(pid_fork2){
                    case -1: perror("fork"); 
                             break;
        
                    case 0: //child 2
                            setpgid(getpid(),pid_fork);
                            
                            if (!background)tcsetpgrp(STDIN_FILENO,pid_fork);
                            terminal_signals(SIG_DFL);

                            if (apply_mask) sigprocmask(SIG_BLOCK, &custom_mask, NULL);


                            //Redireccion de entrada 
                            if (file_out2!=NULL){
                                int f_out=open(file_out2,O_CREAT|O_WRONLY|O_TRUNC,0664);

                                if(f_out==-1){
                                    perror(file_out2);
                                    exit(EXIT_FAILURE);
                                }
                                dup2(f_out,STDOUT_FILENO);
                                close(f_out);
                            }

                            dup2(p[0],STDIN_FILENO);
                            close(p[0]);
                            close(p[1]);


                            execvp(argv_cmd2[0],argv_cmd2);  
                            perror(argv_cmd2[0]);
                            exit(EXIT_FAILURE);
                    
                    default://parent
                            setpgid(pid_fork,pid_fork);
                            setpgid(pid_fork2,pid_fork);
                            *last_pid = pid_fork2;

                            close(p[0]);
                            close(p[1]);

                            mask_signal(SIGCHLD, SIG_BLOCK);
                            char command_name[256];
                            snprintf(command_name, sizeof(command_name), "%s | %s", argv[0], argv_cmd2[0]);

                            if (!background) {
                                pid_wait = waitpid(pid_fork, wstatus, WUNTRACED);
                                int pid_wait2=waitpid(pid_fork2,wstatus,WUNTRACED);
                                tcsetpgrp(STDIN_FILENO,getpid());
                                    
                               if (pid_wait == -1 || pid_wait2==-1){
                                   perror("waitpid");
                                   mask_signal(SIGCHLD, SIG_UNBLOCK); 
                                   break;
                               }
                        
                                if (WIFEXITED(*wstatus)) {
                                    *retval = WEXITSTATUS(*wstatus);
                                    printf("[%d] (%s) Terminated with status: %d\n", pid_fork, command_name, *retval);
                                }
                                    
                                else if (WIFSIGNALED(*wstatus)) {
                                    int sig = WTERMSIG(*wstatus);
                                    printf("[%d] (%s) Signaled by signal: %d\n", pid_fork, command_name, sig);
                                } 
                                    
                                else if (WIFSTOPPED(*wstatus)){
                                    job *task= new_job(pid_fork,command_name,STOPPED);
                                    add_job(job_list,task);
                                    printf("[%d] (%s) Stopped by signal: %d\n", pid_fork, command_name, WSTOPSIG(*wstatus));
                                } 
                                    
                                else printf("[%d] (%s) other\n", pid_fork, command_name);

                                
                                // Gestiono las tareas lanzadas en BACKGROUND
                            } else{
                                job *task= new_job(pid_fork,command_name,BACKGROUND);
                                add_job(job_list,task);
                                printf("[%d] (%s) Running in Background\n", pid_fork, command_name);
                            } 
                            mask_signal(SIGCHLD, SIG_UNBLOCK); 
                            
                        
                }
    }
}
// -----------------------------------------------------------------------------
// SUSTITUCIÓN DE VARIABLES AUTOMÁTICAS Y DE ENTORNO
// -----------------------------------------------------------------------------
int subs_autovars(char **argv, int shell_pid, int last_pid, int retval) {

    for (int i=0;argv[i]!=NULL;i++){
        if (strcmp(argv[i],"$$")==0){
            free(argv[i]);                            
            argv[i] = malloc(32 * sizeof(char));         
            sprintf(argv[i], "%d", shell_pid);
        }
        else if (strcmp(argv[i],"$!")==0){
            if (last_pid!=-1){
                free(argv[i]);                            
                argv[i] = malloc(32 * sizeof(char));         
                sprintf(argv[i], "%d", last_pid);
            }
        }
        else if (strcmp(argv[i],"$?")==0){
            if (retval!=-1){
                free(argv[i]);                            
                argv[i] = malloc(32 * sizeof(char));         
                sprintf(argv[i], "%d", retval);
            }
        }
        
        else if (argv[i][0]=='$' && strlen(argv[i])>1){

            char *nombre_var = argv[i] + 1;

            char *valor= getenv(nombre_var);
            free(argv[i]);

            if (valor!=NULL){
                char *nuevo_arg=malloc((strlen(valor)+1)*sizeof(char));
                strcpy(nuevo_arg,valor);
                argv[i]=nuevo_arg;
            }
            else{

                for (int j=i;argv[j]!=NULL;j++) argv[j]=argv[j+1];
                
                i--;
            }
        }
    }
    
    
    int cont=0;
    while(argv[cont]!=NULL){
        cont++;
    }
    return cont;
}
// -----------------------------------------------------------------------------
//      MANEJADOR DE LA SEÑAL SIGHUP       
// -----------------------------------------------------------------------------
void handler_sighup(int signal){
    FILE *fp;
    fp=fopen("hup.txt","a"); // abre un fichero en modo 'append'
    if (fp) { 
        fprintf(fp, "SIGHUP recibido.\n"); //escribe en el fichero
        fclose(fp);
    }
}
// -----------------------------------------------------------------------------
//      MANEJADOR DE LA SEÑAL SIGCHLD  (Procesos en Background/Suspendidos)      
// -----------------------------------------------------------------------------
void handler_singchld(int signal){
    while(1){
        int wstatus;
        int pid_wait= waitpid(-1, &wstatus, WNOHANG | WUNTRACED | WCONTINUED);
         
        if (pid_wait <= 0) break;

        mask_signal(SIGCHLD, SIG_BLOCK);
        job *task= get_job_bypid(job_list,pid_wait);
        mask_signal(SIGCHLD, SIG_UNBLOCK); 

        if (task == NULL) continue;

        if (WIFEXITED(wstatus)) {
            
            printf("[%d] (%s) Terminated with status: %d\n", task->pgid,task->command,WEXITSTATUS(wstatus));
            mask_signal(SIGCHLD, SIG_BLOCK);
            del_job(job_list,task);
            free_job(task);
            mask_signal(SIGCHLD, SIG_UNBLOCK); 

        }
                    
         else if (WIFSIGNALED(wstatus)) {
            int sig = WTERMSIG(wstatus);
            printf("[%d] (%s) Signaled by signal: %d\n", task->pgid,task->command, sig);
            mask_signal(SIGCHLD, SIG_BLOCK);
            del_job(job_list,task);
            free_job(task);
            mask_signal(SIGCHLD, SIG_UNBLOCK); 
        } 
                    
        else if (WIFSTOPPED(wstatus)){
            mask_signal(SIGCHLD, SIG_BLOCK);
            task->state=STOPPED;
            mask_signal(SIGCHLD, SIG_UNBLOCK);
            printf("[%d] (%s) Stopped by signal: %d\n", task->pgid,task->command, WSTOPSIG(wstatus));
        } 
                    
        else if(WIFCONTINUED(wstatus)) {
            mask_signal(SIGCHLD, SIG_BLOCK);
            task->state=BACKGROUND;
            mask_signal(SIGCHLD, SIG_UNBLOCK);
            printf("[%d] (%s) continued\n", task->pgid,task->command);
        }
    }
}

// -----------------------------------------------------------------------------
//                            MAIN          
// -----------------------------------------------------------------------------
int main(void)
{
    char **argv = NULL;
    int argc;
    int argc2;
    job_list=new_list("Jobs");
    // probably useful variables:
    int background;             // equals 1 if a command is followed by '&'
    int pid_fork, pid_wait,pid_fork2;     // pid for created and waited process
    int wstatus;                // status returned by waitpid
    char *file_in, *file_out;  // for redirections
    char *file_in2, *file_out2;
    int shell_pid=getpid();
    int last_pid=-1;
    sigset_t custom_mask;
    signal(SIGCHLD,handler_singchld);
    signal(SIGHUP,handler_sighup);
    int retval=-1;

    //Apago las señales para que la terminal no pueda ser detenida con ctrl z, ctrl c, etc
    terminal_signals(SIG_IGN);
    while (1) {
       int apply_mask=0;
       int cond_and=0;
       int cond_or=0;
       int is_pipe=0;
       char **argv_cmd2=NULL;
       free_argv(argv);
       int ret = get_command("ShellSO > ", &argc, &argv);
       if (ret == -1) exit(EXIT_FAILURE);      // error in read(2)
       if (ret == 0) break;                    // finish loop if ^D (eof)
       if (argc == 0) continue;                // empty command: next iteration
       argc = parse_comments(argv);
       if (argc == 0) continue; // empty command after parsing comment #

// -----------------------------------------------------------------------------
//                 BÚSQUEDA DE CONDICIONALES
// -----------------------------------------------------------------------------
      //Compruebo tanto los condicionales como el pipe, para poder dividir argv en dos comandos separados  
       for (int i = 0; argv[i] != NULL; i++) {
                   if (strcmp(argv[i], "&&") == 0) {
                           cond_and = 1;
                           argv[i] = NULL;        
                           argv_cmd2 = &argv[i + 1];
                           break;
                    }
                   else if (strcmp(argv[i], "||") == 0) {
                           cond_or = 1;
                           argv[i] = NULL;           
                           argv_cmd2 = &argv[i + 1];
                           break;
                    }
                    else if (strcmp(argv[i], "|") == 0) {
                        is_pipe=1;
                        argv[i] = NULL;           
                        argv_cmd2 = &argv[i + 1];
                        break;
                    } 
        }
       
        if (argv_cmd2!=NULL) argc=parse_background(argv_cmd2, &background);
        else argc = parse_background(argv, &background);
        
        if (argc == 0) continue; // empty command after parsing background &
        
        argc=subs_autovars(argv,shell_pid,last_pid,retval);
        if (argv_cmd2!=NULL) argc2=subs_autovars(argv,shell_pid,last_pid,retval);
        
        argc = parse_redirections(argv,  &file_in, &file_out);
        if (argv_cmd2!=NULL) argc2=parse_redirections(argv,  &file_in2, &file_out2);

        if (argc == 0) continue; // empty command after parsing redirections

        // -----------------------------------------------------------------------------
        //                         COMANDOS INTERNOS           
        // -----------------------------------------------------------------------------        
        
        if (strcmp(argv[0],"quit")==0) break;// 'quit' terminación del shell sin retval
        if (strcmp(argv[0],"exit")==0) {// 'exit retval' terminación con retval
          int retval=0;
          if (argv[1]==NULL) retval=0;
          else retval=atoi(argv[1]);
          exit(retval);
        
        }
        
        // 'cd' para cambiar el directorio de trabajo
        if (strcmp(argv[0],"cd")==0){
            char *dir;

            if (argv[1]==NULL) dir=getenv("HOME");
            else dir=argv[1];

            if (chdir(dir)!=0) perror(argv[0]);
            
            continue;
        }
        // 'jobs' para visualizar la lista de trabajos 
        if (strcmp(argv[0],"jobs")==0){
            mask_signal(SIGCHLD, SIG_BLOCK);       
            print_job_list(job_list);
            mask_signal(SIGCHLD, SIG_UNBLOCK); 

            continue;
        }
        
        //'bg' para lanzar en BACKGROUND un proceso suspendido
        if (strcmp(argv[0],"bg")==0){
            job *task;
            mask_signal(SIGCHLD, SIG_BLOCK);
            if (argv[1]==NULL) task=get_item_bypos(job_list,1);
            
            else task= get_item_bypos(job_list,atoi(argv[1]));

            mask_signal(SIGCHLD, SIG_UNBLOCK); 
            
            if (task==NULL) perror("Not found");

            else{
                mask_signal(SIGCHLD, SIG_BLOCK);
                if (task->state == BACKGROUND){
                    printf("[%d] (%s) Already in BACKGROUND", task->pgid,task->command);
                }
                else if (task->state==STOPPED) {
                    task->state=BACKGROUND;
                    killpg(task->pgid,SIGCONT);
                    printf("[%d] (%s) Running in Background\n", task->pgid,task->command);
                }
                mask_signal(SIGCHLD, SIG_UNBLOCK);
            }
            continue;
        }
        //'fg' para pasar a FOREGROUND una tarea en BACKGROUND o suspendida
        if (strcmp(argv[0],"fg")==0){
            job *task;
            mask_signal(SIGCHLD, SIG_BLOCK);
            if (argv[1]==NULL) task=get_item_bypos(job_list,1);
            
            else task= get_item_bypos(job_list,atoi(argv[1]));

            mask_signal(SIGCHLD, SIG_UNBLOCK); 
            
            if (task==NULL) perror("Not found");

            else{
                mask_signal(SIGCHLD, SIG_BLOCK);
                task->state=FOREGROUND;
                
                tcsetpgrp(STDIN_FILENO,task->pgid);
                killpg(task->pgid,SIGCONT);
                
                
                pid_wait = waitpid(task->pgid, &wstatus, WUNTRACED);
                tcsetpgrp(STDIN_FILENO,getpid());
                
                if (pid_wait == -1) perror("waitpid");
                
                if (WIFEXITED(wstatus)) {
                    retval = WEXITSTATUS(wstatus);
                    printf("[%d] (%s) Terminated with status: %d\n", task->pgid, task->command, retval);
                    del_job(job_list,task);
                    free_job(task);

                }
                    
                else if (WIFSIGNALED(wstatus)) {
                    int sig = WTERMSIG(wstatus);
                    printf("[%d] (%s) Signaled by signal: %d\n", task->pgid, task->command, sig);
                    del_job(job_list,task);
                    free_job(task);
                } 
                    
                else if (WIFSTOPPED(wstatus)){
                    task->state=STOPPED;
                    printf("[%d] (%s) Stopped by signal: %d\n", task->pgid, task->command, WSTOPSIG(wstatus));
                } 
                
                else printf("[%d] (%s) other\n", task->pgid, task->command);
                
                mask_signal(SIGCHLD, SIG_UNBLOCK);
                        
            }
            continue;
        }
        //'mask' para lanzar un comando con señales enmascaradas
        if (strcmp(argv[0],"mask")==0){
            int i=0;
            while ( argv[i]!=NULL && strcmp(argv[i],"-c")!=0) i++;
            
            if(argv[i]==NULL || argv[i+1]==NULL){
                printf("mask: error de sintaxis\n");
                continue;
            }

            sigemptyset(&custom_mask);
            
            int j=1;
            int error=0;
            while (j<i && !error){

                char *resto;
                int sig = strtol(argv[j], &resto, 10);

                // Si *resto no es el final de la cadena ('\0'), es que hay un . o algo incorrecto
                if (*resto != '\0' || sig <= 0) {
                    printf("mask: error de sintaxis\n");
                    error=1;
                }
                else{
                    sigaddset(&custom_mask,sig);
                    j++;
                }
            }

            if (error) continue;
            
            apply_mask=1;

            for (int k=0;argv[k]!=NULL;k++) argv[k]=argv[1+i+k];
                
        }

        if (strcmp(argv[0],"currjob")==0){
            job *task;

            mask_signal(SIGCHLD, SIG_BLOCK);            
            
            task=get_item_bypos(job_list,1);
            
            mask_signal(SIGCHLD, SIG_UNBLOCK); 

            if (task!=NULL) printf("Trabajo actual: PID=%i command=%s\n",task->pgid,task->command);
            else printf("No hay trabajo actual\n");
            continue;
        }

// -----------------------------------------------------------------------------
//                           COMANDOS EXTERNOS          
// -----------------------------------------------------------------------------

//En caso de tener pipe, hago la ejecución de comando de manera distinta creando dos hijos 
        if (is_pipe){
             execute_external_command_pipe(argv, argv_cmd2, background, file_in, file_out2, apply_mask, custom_mask, &last_pid, &retval, &wstatus);
        }
        else{

            execute_external_command(argv, background, file_in, file_out, apply_mask, custom_mask, &last_pid, &retval,&wstatus);
    
            int exito = (WIFEXITED(wstatus) && WEXITSTATUS(wstatus) == 0);
    
            if ((cond_and && exito) || (cond_or && !exito)) {
                if (argv_cmd2 != NULL && argv_cmd2[0] != NULL) {
                execute_external_command(argv_cmd2, background, file_in2, file_out2, apply_mask, custom_mask, &last_pid, &retval,&wstatus);
                }
            }
        }
    } // end while
    printf("\nBye\n");
    return 0;
}



